insert into outlet (outlet_name, address_street, address_city) values
('Spar','Egham','Staines'),
('Smithstore','Tottenham','London'),
('MacD','Oxfordstreet','Oxford'),
('Kfc','Liverpoolstreet','London'),
('BurgerKing','Hull','Manchester');

insert into Customer(customer_nr, customer_name, address_street, address_city) values
(101,'Ash','virgina water','Staines'),
(102,'Ben','chelsea','London'),
(103,'Paul','Hedington','Oxford'),
(104,'Milad','windsor','Newcastle'),
(105,'Philip','Five Sisters','London');

insert into Product(product_id, product_name, description, standard_price) values
(2001,'Clock','Stationary',60.24),
(1024,'Pendrive','Technology',87.33),
(2603,'Wings','FoodItem',12.50),
(1048,'coke','Drink',1.30),
(1051,'Burger','FoodItem',8.51);

insert into Category(category_id, description) values
(3, 'Drink'),
(1, 'Clothes'),
(9, 'Stationary'),
(2, 'FoodItem'),
(6, 'Technology');

INSERT INTO Product_category (product_id, category_id) values
(2001,9),
(1024, 6),
(2603,2),
(1048,3),
(1051,2);

INSERT INTO Purchase ( purchase_id, date_time, outlet_name, customer_nr) values
(11, '2022-03-11 11:20:07', 'Spar', 101),
(12, '2022-04-23 18:01:23', 'Smithstore', 102),
(13, '2022-02-27 14:21:14', 'MacD', 103),
(14, '2022-04-01 15:29:40', 'Kfc', 104),
(15, '2022-09-22 11:50:47', 'BurgerKing', 105);


INSERT INTO PurchaseItem ( purchase_id, product_id, copies, price_per_copy) values
(11, 2001, 1,60.24),
(12, 1048, 4, 1.30),
(13, 2603, 6, 12.50),
(14, 2603,3,12.50),
(15, 1051, 4, 8.51);

INSERT INTO Stock ( outlet_name, product_id, copies) values
( 'Spar', 2001, 10),
('Smithstore',1024, 105),
('Smithstore', 1048, 100),
('Kfc', 1048, 50),
('MacD', 1048, 100),
('Kfc', 2603, 200),
('BurgerKing', 1051, 150);


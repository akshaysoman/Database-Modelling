 
create view purchase_item_total
as
(select purchase_id,product_id,copies,price_per_copy,copies*price_per_copy as item_total  
from PurchaseItem);

create view purchase_total
as
(select purchase_id,sum(item_total) as total_paid
from purchase_item_total group by purchase_id);
 
--query 1 
SELECT purchase.date_time,purchase_total.total_paid,count(distinct (PurchaseItem.product_id))
FROM purchase
INNER JOIN PurchaseItem
ON PurchaseItem.purchase_id = purchase.purchase_id
INNER JOIN purchase_total
ON PurchaseItem.purchase_id = purchase_total.purchase_id
WHERE purchase.outlet_name='Spar'
GROUP BY purchase.outlet_name,purchase.date_time,purchase_total.total_paid
ORDER BY purchase.date_time;

--query 2
SELECT  customer.customer_name,customer.address_city,customer.address_street,
(avg(purchase_total.total_paid),2) AS Average_Price,
max(purchase_total.total_paid) AS Maximum_Price FROM  purchase
INNER JOIN customer 
ON customer.customer_nr = purchase.customer_nr
JOIN purchase_total
ON  purchase.purchase_id = purchase_total.purchase_id
group by purchase.customer_nr,customer.customer_nr;

--query 3
SELECT product.product_name,
sum(stock.copies) AS Stockleft,
sum(purchaseitem.copies) AS SoldCopies
FROM product 
LEFT OUTER JOIN stock 
ON product.product_id= stock.product_id
LEFT  OUTER JOIN purchaseitem  
on stock.product_id=purchaseitem.product_id
GROUP BY 1
ORDER BY SoldCopies DESC;

--query 4
   



create table outlet(
	outlet_name varchar(60) primary key, 
	address_street varchar(60),
	address_city varchar(60)
 );
 create table customer(
	customer_nr int primary key,     
	customer_name varchar(60),
	address_street varchar(60),
	address_city varchar(60)
 );
 create table product(
	product_id int primary key,
	product_name varchar(60),
	description varchar(60),
	standard_price numeric(10,5)
 );
 create table category(
	category_id int primary key,
	description varchar(60)
 );

create table Product_Category(
	product_id int REFERENCES product(product_id) NOT NULL,
	category_id int REFERENCES category(category_id) NOT NULL,
	primary key(product_id,category_id)	
 );

 create table Purchase(
	purchase_id int primary key,
	date_time timestamp,
	outlet_name varchar(60) REFERENCES outlet(outlet_name),
	customer_nr int REFERENCES customer(customer_nr)
 );
 create table PurchaseItem(
	purchase_id int REFERENCES Purchase(purchase_id) ,
	product_id int REFERENCES product(product_id) ,
	copies int,
	price_per_copy numeric(15,5),
	primary key(purchase_id,product_id)
 );
 
create table Stock(
	outlet_name varchar(60) REFERENCES outlet(outlet_name) ,
	product_id int REFERENCES product(product_id) ,
	copies int,
	primary key(outlet_name,product_id)
 );
 
